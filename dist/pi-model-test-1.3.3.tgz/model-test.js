var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// shared/format.ts
function section(title) {
  return `
\u2500\u2500 ${title} ${"\u2500".repeat(Math.max(1, 60 - title.length - 4))}`;
}
function ok(msg) {
  return `  \u2705 ${msg}`;
}
function fail(msg) {
  return `  \u274C ${msg}`;
}
function warn(msg) {
  return `  \u26A0\uFE0F  ${msg}`;
}
function info(msg) {
  return `  \u2139\uFE0F  ${msg}`;
}
function msHuman(ms) {
  if (ms < 1e3) return `${ms.toFixed(0)}ms`;
  if (ms < 6e4) return `${(ms / 1e3).toFixed(1)}s`;
  return `${(ms / 6e4).toFixed(1)}m`;
}
function truncate(s, max) {
  return s.length > max ? s.slice(0, max) + "..." : s;
}
function sanitizeForReport(s, maxLines = 40) {
  let cleaned = s.replace(/^\s*```[a-zA-Z]*[ \t]*\n?/gm, "");
  cleaned = cleaned.replace(/^\s*```[ \t]*\n?/gm, "");
  cleaned = cleaned.replace(/\n{3,}/g, "\n\n").trim();
  if (/<!DOCTYPE\b|<html[\s>]/i.test(cleaned) || /<[a-z][\s\S]*>/i.test(cleaned) && cleaned.includes("</") && /<(?:div|span|p|head|body|html|table|form|script)\b/i.test(cleaned)) {
    const firstLine = cleaned.split("\n")[0];
    return truncate(firstLine, 200) + "\n  \u2139\uFE0F  (HTML response truncated)";
  }
  const lines = cleaned.split("\n");
  if (lines.length > maxLines) {
    cleaned = lines.slice(0, maxLines).join("\n") + `
  \u2139\uFE0F  (truncated, ${lines.length - maxLines} more lines)`;
  }
  return cleaned;
}

// shared/ollama.ts
import * as fs from "node:fs";
import * as path from "node:path";
import os from "node:os";

// shared/debug.ts
var DEBUG_ENABLED = process?.env?.PI_EXTENSIONS_DEBUG === "1";
function debugLog(module, message, ...args) {
  if (!DEBUG_ENABLED) return;
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  console.debug(`[pi-ext:${module}] ${timestamp} ${message}`, ...args);
}

// shared/ollama.ts
var EXTENSION_VERSION = "1.3.3";
var MODELS_JSON_PATH = path.join(os.homedir(), ".pi", "agent", "models.json");
var _modelsJsonCache = null;
var _ollamaBaseUrlCache = null;
var CACHE_TTL_MS = 2e3;
function getOllamaBaseUrl() {
  const now = Date.now();
  if (_ollamaBaseUrlCache && now - _ollamaBaseUrlCache.ts < CACHE_TTL_MS) return _ollamaBaseUrlCache.data;
  try {
    if (fs.existsSync(MODELS_JSON_PATH)) {
      const raw = fs.readFileSync(MODELS_JSON_PATH, "utf-8");
      const config = JSON.parse(raw);
      const baseUrl = config?.providers?.["ollama"]?.baseUrl;
      if (baseUrl) {
        const result = baseUrl.replace(/\/v1\/?$/, "");
        _ollamaBaseUrlCache = { data: result, ts: now };
        return result;
      }
    }
  } catch (err) {
    debugLog("ollama", "failed to parse models.json for base URL", err);
  }
  if (process.env.OLLAMA_HOST) {
    const result = `http://${process.env.OLLAMA_HOST.replace(/^https?:\/\//, "")}`;
    _ollamaBaseUrlCache = { data: result, ts: now };
    return result;
  }
  const fallback = "http://localhost:11434";
  _ollamaBaseUrlCache = { data: fallback, ts: now };
  return fallback;
}
function readModelsJson() {
  const now = Date.now();
  if (_modelsJsonCache && now - _modelsJsonCache.ts < CACHE_TTL_MS) return _modelsJsonCache.data;
  try {
    if (fs.existsSync(MODELS_JSON_PATH)) {
      const raw = fs.readFileSync(MODELS_JSON_PATH, "utf-8");
      const data = JSON.parse(raw);
      _modelsJsonCache = { data, ts: now };
      return data;
    }
  } catch (err) {
    debugLog("ollama", "failed to read/parse models.json", err);
  }
  const empty = { providers: {} };
  _modelsJsonCache = { data: empty, ts: now };
  return empty;
}
var BUILTIN_PROVIDERS = {
  openrouter: { api: "openai-completions", baseUrl: "https://openrouter.ai/api/v1", envKey: "OPENROUTER_API_KEY" },
  anthropic: { api: "anthropic-messages", baseUrl: "https://api.anthropic.com/v1", envKey: "ANTHROPIC_API_KEY" },
  google: { api: "gemini", baseUrl: "https://generativelanguage.googleapis.com", envKey: "GOOGLE_API_KEY" },
  openai: { api: "openai-completions", baseUrl: "https://api.openai.com/v1", envKey: "OPENAI_API_KEY" },
  groq: { api: "openai-completions", baseUrl: "https://api.groq.com/v1", envKey: "GROQ_API_KEY" },
  deepseek: { api: "openai-completions", baseUrl: "https://api.deepseek.com/v1", envKey: "DEEPSEEK_API_KEY" },
  mistral: { api: "openai-completions", baseUrl: "https://api.mistral.ai/v1", envKey: "MISTRAL_API_KEY" },
  xai: { api: "openai-completions", baseUrl: "https://api.x.ai/v1", envKey: "XAI_API_KEY" },
  together: { api: "openai-completions", baseUrl: "https://api.together.xyz/v1", envKey: "TOGETHER_API_KEY" },
  fireworks: { api: "openai-completions", baseUrl: "https://api.fireworks.ai/inference/v1", envKey: "FIREWORKS_API_KEY" },
  cohere: { api: "cohere-chat", baseUrl: "https://api.cohere.com/v1", envKey: "COHERE_API_KEY" },
  zai: { api: "openai-completions", baseUrl: "https://open.bigmodel.cn/api/paas/v4", envKey: "ZAI_API_KEY" }
};
function detectProvider(ctx, modelsJson) {
  const model = ctx.model;
  if (!model) return { kind: "unknown", name: "none" };
  const providerName = model.provider || "";
  if (!providerName) return { kind: "unknown", name: "none" };
  const effectiveModelsJson = modelsJson ?? readModelsJson();
  const userProviderCfg = (effectiveModelsJson.providers || {})[providerName];
  if (userProviderCfg) {
    const baseUrl = userProviderCfg.baseUrl || "";
    const apiMode = userProviderCfg.api || "";
    const apiKey = userProviderCfg.apiKey || "";
    const isOllama = /ollama/i.test(providerName) || /localhost:\d+/.test(baseUrl) || /127\.0\.0\.1:\d+/.test(baseUrl) || /0\.0\.0\.0:\d+/.test(baseUrl) || /\/api\/chat/.test(baseUrl) || apiMode === "ollama";
    if (isOllama) {
      return { kind: "ollama", name: providerName, apiMode: "ollama", baseUrl, apiKey };
    }
    if (/\/api\/chat/.test(baseUrl)) {
      return { kind: "ollama", name: providerName, apiMode: "ollama", baseUrl, apiKey };
    }
    return {
      kind: "builtin",
      name: providerName,
      apiMode: apiMode || "openai-completions",
      baseUrl,
      apiKey
    };
  }
  const builtin = BUILTIN_PROVIDERS[providerName];
  if (builtin) {
    const userProviderCfg2 = (effectiveModelsJson.providers || {})[providerName];
    const apiKeyFromConfig = userProviderCfg2?.apiKey || "";
    const apiKeyFromEnv = process.env[builtin.envKey] || "";
    const apiKey = apiKeyFromConfig || apiKeyFromEnv;
    return {
      kind: "builtin",
      name: providerName,
      apiMode: builtin.api,
      baseUrl: builtin.baseUrl,
      envKey: builtin.envKey,
      apiKey
    };
  }
  return { kind: "unknown", name: providerName };
}

// shared/model-test-utils.ts
import * as fs2 from "node:fs";
import * as os2 from "node:os";
import * as path2 from "node:path";
var CONFIG = {
  // General API settings - standardized across all providers
  DEFAULT_TIMEOUT_MS: 3e5,
  // 5 minutes - reasonable timeout for all providers
  CONNECT_TIMEOUT_S: 60,
  // 60 seconds to establish connection
  MAX_RETRIES: 2,
  // Two retries for transient failures (standardized)
  RETRY_DELAY_MS: 15e3,
  // 15 seconds between retries (standardized)
  // Model generation settings
  NUM_PREDICT: 1024,
  // Max tokens in response
  TEMPERATURE: 0.1,
  // Low temperature for more deterministic output
  // Test-specific settings - standardized across all providers
  MIN_THINKING_LENGTH: 10,
  // Minimum chars to consider thinking tokens valid
  TOOL_TEST_TIMEOUT_MS: 3e5,
  // 5 minutes - consistent timeout for tool usage tests
  TOOL_SUPPORT_TIMEOUT_MS: 3e5,
  // 5 minutes - consistent timeout for tool support detection
  // Metadata retrieval
  TAGS_TIMEOUT_MS: 15e3,
  // 15 seconds for /api/tags
  MODEL_INFO_TIMEOUT_MS: 3e4,
  // 30 seconds for model info lookup
  // Provider API settings
  PROVIDER_TIMEOUT_MS: 3e5,
  // 5 minutes - consistent with Ollama
  PROVIDER_TOOL_TIMEOUT_MS: 3e5,
  // 5 minutes - consistent with Ollama tool tests
  // Context length fetching
  CONTEXT_BATCH_SIZE: 3,
  // Concurrent requests when fetching model context lengths
  // Rate limiting
  TEST_DELAY_MS: 4e3,
  // 4 seconds between tests to avoid rate limiting
  // Cache management
  MAX_CACHE_SIZE: 1e3,
  // Maximum number of entries in tool support cache
  CACHE_TTL_DAYS: 30,
  // Cache entries expire after 30 days
  CACHE_CLEANUP_SIZE: 200
  // Remove oldest 200 entries during cleanup
};
var TEST_CONFIG_DIR = path2.join(os2.homedir(), ".pi", "agent");
var TEST_CONFIG_PATH = path2.join(TEST_CONFIG_DIR, "model-test-config.json");
function readTestConfig() {
  try {
    if (fs2.existsSync(TEST_CONFIG_PATH)) {
      const raw = fs2.readFileSync(TEST_CONFIG_PATH, "utf-8");
      return JSON.parse(raw);
    }
  } catch {
  }
  return {};
}
function getEffectiveConfig() {
  const userConfig = readTestConfig();
  return {
    ...CONFIG,
    DEFAULT_TIMEOUT_MS: userConfig.defaultTimeoutMs ?? CONFIG.DEFAULT_TIMEOUT_MS,
    CONNECT_TIMEOUT_S: userConfig.connectTimeoutS ?? CONFIG.CONNECT_TIMEOUT_S,
    MAX_RETRIES: userConfig.maxRetries ?? CONFIG.MAX_RETRIES,
    RETRY_DELAY_MS: userConfig.retryDelayMs ?? CONFIG.RETRY_DELAY_MS,
    TEST_DELAY_MS: userConfig.testDelayMs ?? CONFIG.TEST_DELAY_MS,
    TOOL_TEST_TIMEOUT_MS: userConfig.toolTestTimeoutMs ?? CONFIG.TOOL_TEST_TIMEOUT_MS,
    PROVIDER_TIMEOUT_MS: userConfig.providerTimeoutMs ?? CONFIG.PROVIDER_TIMEOUT_MS,
    PROVIDER_TOOL_TIMEOUT_MS: userConfig.providerToolTimeoutMs ?? CONFIG.PROVIDER_TOOL_TIMEOUT_MS,
    CONTEXT_BATCH_SIZE: userConfig.contextBatchSize ?? CONFIG.CONTEXT_BATCH_SIZE,
    NUM_PREDICT: userConfig.numPredict ?? CONFIG.NUM_PREDICT,
    TEMPERATURE: userConfig.temperature ?? CONFIG.TEMPERATURE
  };
}
var WEATHER_TOOL_DEFINITION = {
  type: "function",
  function: {
    name: "get_weather",
    description: "Get the current weather for a location",
    parameters: {
      type: "object",
      properties: {
        location: { type: "string", description: "City name" },
        unit: { type: "string", enum: ["celsius", "fahrenheit"] }
      },
      required: ["location"]
    }
  }
};
var TOOL_SUPPORT_CACHE_DIR = path2.join(os2.homedir(), ".pi", "agent", "cache");
var TOOL_SUPPORT_CACHE_PATH2 = path2.join(TOOL_SUPPORT_CACHE_DIR, "tool_support.json");
var TEST_HISTORY_DIR = path2.join(os2.homedir(), ".pi", "agent", "cache");
var TEST_HISTORY_PATH = path2.join(TEST_HISTORY_DIR, "model-test-history.json");

// shared/test-report.ts
var branding = [
  `  \u26A1 Pi Model Benchmark v${EXTENSION_VERSION}`,
  `  Written by VTSTech`,
  `  GitHub: https://github.com/VTSTech`,
  `  Website: www.vts-tech.org`
].join("\n");
function formatTestSummary(tests, totalMs) {
  const lines = [];
  lines.push(section("SUMMARY"));
  for (const t of tests) {
    lines.push(t.pass ? ok(`${t.name}: ${t.score}`) : fail(`${t.name}: ${t.score}`));
  }
  lines.push(info(`Total time: ${msHuman(totalMs)}`));
  const passed = tests.filter((t) => t.pass).length;
  lines.push(info(`Score: ${passed}/${tests.length} tests passed`));
  return lines;
}
function formatRecommendation(model, passed, total, via) {
  const suffix = via ? ` via ${via}` : "";
  const lines = [];
  lines.push(section("RECOMMENDATION"));
  if (passed === total) {
    lines.push(ok(`${model} is a STRONG model${suffix} \u2014 full capability`));
  } else if (passed > 0 && passed >= total - 1) {
    lines.push(ok(`${model} is a GOOD model${suffix} \u2014 most capabilities work`));
  } else if (passed > 0 && passed >= total - 2) {
    lines.push(warn(`${model} is USABLE${suffix} \u2014 some capabilities are limited`));
  } else {
    lines.push(fail(`${model} is WEAK${suffix} \u2014 limited capabilities for agent use`));
  }
  return lines;
}

// extensions/model-test.ts
function model_test_default(pi) {
  const effectiveConfig = getEffectiveConfig();
  function ollamaBase() {
    return getOllamaBaseUrl();
  }
  async function rateLimitDelay() {
    if (effectiveConfig.TEST_DELAY_MS > 0) {
      await new Promise((r) => setTimeout(r, effectiveConfig.TEST_DELAY_MS));
    }
  }
  function reportReasoningScore(lines, result) {
    const msg = result.reasoning.toLowerCase().trim();
    const isCorrect = result.answer === "8";
    const reasoningPatterns = [
      "because",
      "therefore",
      "since",
      "step",
      "subtract",
      "minus",
      "each day",
      "each night",
      "slides",
      "climbs",
      "night",
      "reaches",
      "finally",
      "last day"
    ];
    const hasReasoning = reasoningPatterns.some((w) => msg.includes(w)) || /^\s*\d+\.\s/m.test(msg);
    if (isCorrect && hasReasoning) {
      lines.push(ok(`Answer: ${result.answer} \u2014 Correct with clear reasoning (${result.score})`));
    } else if (isCorrect) {
      lines.push(ok(`Answer: ${result.answer} \u2014 Correct but weak reasoning (${result.score})`));
    } else if (hasReasoning) {
      lines.push(warn(`Answer: ${result.answer} \u2014 Reasoned but wrong answer (${result.score})`));
    } else {
      lines.push(fail(`Answer: ${result.answer} \u2014 No reasoning detected (${result.score})`));
    }
  }
  function reportInstructionScore(lines, result) {
    if (result.score === "STRONG") {
      lines.push(ok(`JSON output valid with correct values (${result.score})`));
    } else if (result.score === "MODERATE") {
      lines.push(ok(`JSON output valid but some values incorrect (${result.score})`));
    } else if (result.score === "WEAK") {
      lines.push(warn(`Partial JSON compliance (${result.score})`));
    } else {
      lines.push(fail(`Failed to produce valid JSON (${result.score})`));
    }
  }
  function reportToolScore(lines, result) {
    if (result.score === "STRONG" || result.score === "MODERATE") {
      lines.push(ok(`Tool call: ${result.toolCall} (${result.score})`));
    } else if (result.score === "WEAK") {
      lines.push(warn(`Tool call: ${result.toolCall} (${result.score}) \u2014 malformed call`));
    } else if (result.score === "FAIL") {
      const hasResponse = result.response && result.response.trim().length > 0;
      lines.push(fail(`Tool call: none \u2014 ${hasResponse ? "model responded in text instead" : "model returned empty response"} (${result.score})`));
    } else {
      lines.push(fail(`Error: ${result.toolCall}`));
    }
    if (result.score === "STRONG" || result.score === "MODERATE" || result.score === "WEAK") {
      if (result.response) {
        lines.push(info(`Raw response: ${sanitizeForReport(result.response)}`));
      }
    } else if (result.score === "FAIL") {
      const hasResponse = result.response && result.response.trim().length > 0;
      if (hasResponse) {
        lines.push(info(`Text response: ${sanitizeForReport(result.response)}`));
      } else {
        lines.push(info("Text response: (empty)"));
      }
    }
  }
  const REASONING_TESTS = [
    // Original tests
    { name: "snail_wall", prompt: "A snail climbs 3 feet up a wall each day, but slides back 2 feet each night. The wall is 10 feet tall. How many days does it take the snail to reach the top? Think step by step. ANSWER: <number>", expectedAnswer: "8", category: "logic" },
    { name: "math_sequence", prompt: "What is the next number in this sequence: 2, 6, 18, 54, ? Think step by step. ANSWER: <number>", expectedAnswer: "162", category: "math" },
    { name: "spatial_directions", prompt: "If you face north and turn 90 degrees clockwise, then face west and turn 180 degrees counter-clockwise, which direction are you facing? ANSWER: <direction>", expectedAnswer: "south", category: "spatial" },
    { name: "commonsense", prompt: "A rooster laid an egg on top of the world's highest building. Which side is the egg on? ANSWER: <side>", expectedAnswer: "the other side", category: "commonsense" },
    { name: "code_simplify", prompt: "Simplify this code to one line: let x = 0; for(let i=1; i<=5; i++) x += i; ANSWER: <code>", expectedAnswer: "15", category: "code" },
    // Phase 2: Counter-intuitive reasoning
    { name: "bat_and_ball", prompt: "A bat and a ball cost $1.10 total. The bat costs $1 more than the ball. How much does the ball cost? Think step by step. ANSWER: <number> cents", expectedAnswer: "5", category: "counterint" },
    { name: "scale_weight", prompt: "A scale weight is 100g. A similar scale weight is 4 times as heavy. How much does the second one weigh? Answer in grams. ANSWER: <number>", expectedAnswer: "400", category: "counterint" },
    // Phase 2: Logical deduction
    { name: "syllogism", prompt: "All mammals are warm-blooded. All dogs are mammals. Therefore, what can we conclude about dogs? Answer with the conclusion. ANSWER: <conclusion>", expectedAnswer: "warm-blooded", category: "logic" },
    { name: "if_then_chain", prompt: "If it rains, the ground gets wet. If the ground gets wet, the grass grows. It is raining. What happens? Think step by step. ANSWER: <outcome>", expectedAnswer: "grass grows", category: "logic" },
    // Phase 2: Causal reasoning
    { name: "cause_effect", prompt: "If you plant a seed in good soil with water and sunlight, what happens? Think about cause and effect. ANSWER: <outcome>", expectedAnswer: "grows", category: "causal" },
    // Phase 2: Comparative reasoning
    { name: "relative_quantities", prompt: "Tom has 3 times as many apples as Sara. Sara has 5 apples. How many apples does Tom have? ANSWER: <number>", expectedAnswer: "15", category: "comparative" },
    // Phase 2: Analogical reasoning
    { name: "analogy_1", prompt: "Book is to Shelf as Chair is to what? Think about relationships. ANSWER: <container>", expectedAnswer: "room", category: "analogy" },
    { name: "analogy_2", prompt: "Hand is to Glove as Foot is to what? ANSWER: <item>", expectedAnswer: "boot", category: "analogy" },
    // Phase 2: Common sense (physical properties)
    { name: "physics_1", prompt: "Does a bowling ball or a tennis ball have more mass? ANSWER: <object>", expectedAnswer: "bowling ball", category: "commonsense" },
    { name: "physics_2", prompt: "What happens to a metal spoon when heated? It usually becomes...? ANSWER: <state>", expectedAnswer: "hot", category: "commonsense" },
    // Phase 2: Common sense (everyday objects)
    { name: "objects_1", prompt: "What tool would you use to cut paper? ANSWER: <tool>", expectedAnswer: "scissors", category: "commonsense" },
    // Phase 2: Common sense (social situations)
    { name: "social_1", prompt: "If someone says 'please' and 'thank you', they are usually considered...? ANSWER: <trait>", expectedAnswer: "polite", category: "commonsense" },
    // Phase 2: Common sense (animals/nature)
    { name: "animals_1", prompt: "What do dolphins live in? ANSWER: <environment>", expectedAnswer: "water", category: "commonsense" },
    // Phase 2: General knowledge
    { name: "gk_1", prompt: "Which planet is known as the Red Planet? ANSWER: <planet>", expectedAnswer: "mars", category: "commonsense" },
    { name: "gk_2", prompt: "How many days are in a leap year? ANSWER: <number>", expectedAnswer: "366", category: "commonsense" }
  ];
  function extractAnswer(msg, expectedAnswer) {
    const msgTrimmed = msg.trim();
    const isNumericAnswer = /^\d+$/.test(expectedAnswer);
    if (isNumericAnswer) {
      const allNumbers = msgTrimmed.match(/\b(\d+)\b/g) || [];
      return allNumbers.length > 0 ? allNumbers[allNumbers.length - 1] : "?";
    } else {
      const msgLower = msgTrimmed.toLowerCase();
      const expectedLower = expectedAnswer.toLowerCase();
      if (msgLower.includes(expectedLower)) {
        return expectedAnswer;
      }
      const answerPatterns = [
        `answer[:s]+(${expectedLower})`,
        `answers?[:s]+(${expectedLower})`,
        `is[:s]+(${expectedLower})`,
        `are[:s]+(${expectedLower})`,
        `result[:s]+(${expectedLower})`,
        `conclusion[:s]+(${expectedLower})`,
        `tool[:s]+(${expectedLower})`,
        `way[:s]+(${expectedLower})`,
        `side[:s]+(${expectedLower})`
      ];
      for (const pattern of answerPatterns) {
        const regex = new RegExp(pattern, "i");
        if (regex.test(msgTrimmed)) {
          return expectedAnswer;
        }
      }
      const questionKeywords = [
        "what",
        "which",
        "how many",
        "how much",
        "name",
        "word",
        "tool",
        "side",
        "direction",
        "planet",
        "metal",
        "state",
        "environment",
        "trait",
        "object",
        "item",
        "container",
        "outcome",
        "conclusion",
        "answer"
      ];
      for (const keyword of questionKeywords) {
        const regex = new RegExp(`${keyword}[^.!?]*?(${expectedLower})`, "i");
        const match = msgTrimmed.match(regex);
        if (match) {
          return expectedAnswer;
        }
      }
      const quotedMatch = msgTrimmed.match(new RegExp(`"([^"]*${expectedLower}[^"]*)"`, "i"));
      if (quotedMatch) {
        return expectedAnswer;
      }
      if (msgTrimmed.split(/\s+/).length <= 10 && msgLower.includes(expectedLower.substring(0, 3))) {
        return expectedAnswer;
      }
      return "?";
    }
  }
  function scoreReasoningExtended(msg, expectedAnswer) {
    const msgLower = msg.toLowerCase().trim();
    const answer = extractAnswer(msg, expectedAnswer);
    const isNumericAnswer = /^\d+$/.test(expectedAnswer);
    let isCorrect;
    let details = "";
    if (isNumericAnswer) {
      isCorrect = answer === expectedAnswer;
      details += ` (expected: ${expectedAnswer}, got: ${answer})`;
    } else {
      isCorrect = answer === expectedAnswer || msgLower.includes(expectedAnswer.toLowerCase());
      details += ` (expected: ${expectedAnswer}, got: ${answer})`;
    }
    const reasoningPatterns = ["because", "therefore", "since", "step", "subtract", "minus", "each day", "each night", "slides", "climbs", "night", "reaches", "finally", "last day", "sequence", "pattern", "multiply", "clockwise", "counter", "facing", "egg", "rooster", "cost", "dollar", "heavy", "mammal", "warm", "grow", "apple", "rains", "wet", "grass", "plant", "seed", "soil", "sunlight", "water", "times", "more", "less", "than", "paper", "tool", "polite", "dolphin", "red", "planet", "leap", "hand", "glove", "foot", "boot", "metal", "bowling", "tennis"];
    const hasReasoning = reasoningPatterns.some((w) => msgLower.includes(w)) || /^\s*\d+\.\s/m.test(msg) || /^(1|2|3)\.\s/m.test(msg);
    if (isCorrect && hasReasoning) return { score: "STRONG", pass: true, details };
    if (isCorrect) return { score: "MODERATE", pass: true, details };
    if (hasReasoning) return { score: "WEAK", pass: false, details };
    return { score: "FAIL", pass: false, details };
  }
  function averageScore(scores) {
    const weights = { STRONG: 3, MODERATE: 2, WEAK: 1, FAIL: 0, ERROR: 0 };
    const avg = scores.reduce((sum, s) => sum + (weights[s] || 0), 0) / scores.length;
    if (avg >= 2.5) return "STRONG";
    if (avg >= 1.5) return "MODERATE";
    if (avg >= 0.5) return "WEAK";
    return "FAIL";
  }
  const MULTISTEP_INSTRUCTION = `You must respond with ONLY a valid JSON object. No markdown, no explanation.
The JSON object must have exactly these keys:
{
  "name": "<your model name>",
  "can_count": true,
  "sum": 42,
  "language": "English",
  "colors": ["red", "blue", "green"],
  "timestamp": "<current time in ISO format>"
}
Return only the JSON.`;
  const CALC_TOOL_DEFINITION = {
    type: "function",
    function: { name: "calculate", description: "Perform a mathematical calculation", parameters: { type: "object", properties: { expression: { type: "string" } }, required: ["expression"] } }
  };
  function makeOllamaChatFn(useStreaming = true) {
    return async (model, messages, _options) => {
      const chatFn = useStreaming ? ollamaChatStream : ollamaChat;
      const result = await chatFn(model, messages);
      return {
        content: result.response?.message?.content || "",
        elapsedMs: result.elapsedMs,
        raw: result.response
      };
    };
  }
  function makeOpenAiChatFn(baseUrl, apiKey) {
    return async (model, messages, options) => {
      const tools = options?.tools || void 0;
      const body = {
        model,
        messages,
        stream: false,
        temperature: CONFIG.TEMPERATURE,
        max_tokens: CONFIG.NUM_PREDICT
      };
      if (tools && tools.length > 0) {
        body.tools = tools.map((t) => ({
          type: "function",
          function: {
            name: t.function?.name || t.name,
            description: t.function?.description || t.description,
            parameters: t.function?.parameters || t.parameters
          }
        }));
      }
      const headers = { "Content-Type": "application/json" };
      if (apiKey) {
        headers["Authorization"] = `Bearer ${apiKey}`;
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), CONFIG.TOOL_TEST_TIMEOUT_MS);
      const start = Date.now();
      try {
        const res = await fetch(`${baseUrl}/chat/completions`, {
          method: "POST",
          headers,
          body: JSON.stringify(body),
          signal: controller.signal
        });
        const elapsedMs = Date.now() - start;
        clearTimeout(timeoutId);
        if (!res.ok) {
          const errorText = await res.text().catch(() => "unknown error");
          throw new Error(`OpenAI API returned ${res.status}: ${truncate(errorText, 200)}`);
        }
        const parsed = await res.json();
        const choice = parsed?.choices?.[0];
        const content = choice?.message?.content || "";
        const toolCalls = choice?.message?.tool_calls;
        return {
          content,
          toolCalls: toolCalls && toolCalls.length > 0 ? toolCalls : void 0,
          elapsedMs,
          raw: parsed
        };
      } catch (e) {
        clearTimeout(timeoutId);
        throw e;
      }
    };
  }
  function makeChatFn(providerInfo) {
    if (providerInfo.kind === "ollama") {
      return makeOllamaChatFn();
    }
    const baseUrl = providerInfo.baseUrl || ollamaBase();
    return makeOpenAiChatFn(baseUrl, providerInfo.apiKey);
  }
  function makeOllamaToolChatFn() {
    return async (model, messages, options) => {
      const tools = options?.tools || void 0;
      const body = {
        model,
        messages,
        stream: false,
        options: { num_predict: CONFIG.NUM_PREDICT, temperature: CONFIG.TEMPERATURE }
      };
      if (tools && tools.length > 0) {
        body.tools = tools;
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), CONFIG.TOOL_TEST_TIMEOUT_MS);
      const start = Date.now();
      try {
        const res = await fetch(`${ollamaBase()}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          signal: controller.signal
        });
        const elapsedMs = Date.now() - start;
        clearTimeout(timeoutId);
        if (!res.ok) {
          const errorText = await res.text().catch(() => "unknown error");
          throw new Error(`Ollama API returned ${res.status}: ${truncate(errorText, 200)}`);
        }
        const text = await res.text();
        if (!text.trim()) throw new Error("Empty response from Ollama");
        const parsed = JSON.parse(text);
        const toolCalls = parsed?.message?.tool_calls;
        const content = parsed?.message?.content || "";
        return {
          content,
          toolCalls: toolCalls && toolCalls.length > 0 ? toolCalls : void 0,
          elapsedMs,
          raw: parsed
        };
      } catch (e) {
        clearTimeout(timeoutId);
        throw e;
      }
    };
  }
  async function ollamaChat(model, messages, options = {}, timeoutMs = CONFIG.DEFAULT_TIMEOUT_MS, retries = CONFIG.MAX_RETRIES) {
    const body = { model, messages, stream: false, options: { num_predict: CONFIG.NUM_PREDICT, temperature: CONFIG.TEMPERATURE, ...options } };
    const url = `${ollamaBase()}/api/chat`;
    for (let attempt = 0; attempt <= retries; attempt++) {
      const start = Date.now();
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          signal: controller.signal
        });
        const elapsedMs = Date.now() - start;
        if (!res.ok) {
          const errorText = await res.text().catch(() => "unknown error");
          throw new Error(`Ollama API returned ${res.status}: ${truncate(errorText, 200)}`);
        }
        const text = await res.text();
        if (!text.trim()) {
          if (attempt < retries) {
            await new Promise((r) => setTimeout(r, CONFIG.RETRY_DELAY_MS));
            continue;
          }
          throw new Error(`Empty response from Ollama after ${attempt + 1} attempt(s)`);
        }
        const parsed = JSON.parse(text);
        return { response: parsed, elapsedMs };
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        if (e instanceof Error && e.name === "AbortError") {
          if (attempt < retries) {
            await new Promise((r) => setTimeout(r, CONFIG.RETRY_DELAY_MS));
            continue;
          }
          throw new Error(`Ollama API timed out after ${msHuman(timeoutMs)}`);
        }
        if (attempt < retries && (msg.includes("Empty response") || msg.includes("ECONNREFUSED") || msg.includes("ECONNRESET") || msg.includes("fetch failed"))) {
          await new Promise((r) => setTimeout(r, CONFIG.RETRY_DELAY_MS));
          continue;
        }
        throw e;
      } finally {
        clearTimeout(timeoutId);
      }
    }
    throw new Error("Unreachable");
  }
  async function ollamaChatStream(model, messages, options = {}, timeoutMs = CONFIG.DEFAULT_TIMEOUT_MS) {
    const body = { model, messages, stream: true, options: { num_predict: CONFIG.NUM_PREDICT, temperature: CONFIG.TEMPERATURE, ...options } };
    const url = `${ollamaBase()}/api/chat`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    const start = Date.now();
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: controller.signal
      });
      if (!res.ok) {
        const errorText = await res.text().catch(() => "unknown error");
        throw new Error(`Ollama API returned ${res.status}: ${truncate(errorText, 200)}`);
      }
      if (!res.body) {
        throw new Error("Ollama streaming response has no body");
      }
      let messageContent = "";
      let thinkingContent = "";
      let done = false;
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      while (!done) {
        const { value, done: streamDone } = await reader.read();
        if (streamDone) break;
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n").filter((line) => line.trim().length > 0);
        for (const line of lines) {
          try {
            const parsed = JSON.parse(line);
            if (parsed.message?.content) messageContent += parsed.message.content;
            if (parsed.message?.thinking) thinkingContent += parsed.message.thinking;
            if (parsed.done) done = true;
          } catch (err) {
            debugLog("model-test", "skipped malformed JSON chunk in streaming response", err);
          }
        }
      }
      const elapsedMs = Date.now() - start;
      if (!messageContent.trim() && !thinkingContent.trim()) {
        throw new Error("Empty streaming response from Ollama");
      }
      const response = {
        message: {
          content: messageContent,
          thinking: thinkingContent,
          role: "assistant"
        },
        done: true
      };
      return { response, elapsedMs };
    } catch (e) {
      if (e instanceof Error && e.name === "AbortError") {
        throw new Error(`Ollama API timed out after ${msHuman(timeoutMs)}`);
      }
      throw e;
    } finally {
      clearTimeout(timeoutId);
    }
  }
  async function testReasoningExtended(chatFn, model, onProgress) {
    const results = [];
    const total = REASONING_TESTS.length;
    for (let i = 0; i < total; i++) {
      const test = REASONING_TESTS[i];
      onProgress?.(`[1/3] Reasoning ${i + 1}/${total}: ${test.name} (${test.category})...`);
      try {
        const result = await chatFn(model, [{ role: "user", content: test.prompt }]);
        const msg = result.content.trim();
        const answer = extractAnswer(msg, test.expectedAnswer);
        const scored = scoreReasoningExtended(msg, test.expectedAnswer);
        results.push({ name: test.name, category: test.category, score: scored.score, answer, expectedAnswer: test.expectedAnswer, pass: scored.pass, details: scored.details });
        onProgress?.(`[1/3] Reasoning ${i + 1}/${total}: ${test.name} \u2192 ${scored.score}`);
      } catch {
        results.push({ name: test.name, category: test.category, score: "ERROR", answer: "?", expectedAnswer: test.expectedAnswer, pass: false });
        onProgress?.(`[1/3] Reasoning ${i + 1}/${total}: ${test.name} \u2192 ERROR`);
      }
      if (i < total - 1) await rateLimitDelay();
    }
    return { score: averageScore(results.map((r) => r.score)), scores: results.map((r) => r.score), answers: results.map((r) => r.answer), results };
  }
  async function testInstructionFollowingExtended(chatFn, model) {
    const start = Date.now();
    try {
      const result = await chatFn(model, [{ role: "user", content: MULTISTEP_INSTRUCTION }]);
      const parsed = JSON.parse(result.content.trim());
      const schemaValid = !!(parsed.name && parsed.can_count === true && parsed.sum === 42 && parsed.language && parsed.colors?.length === 3 && parsed.timestamp);
      if (schemaValid) return { pass: true, score: "STRONG", output: JSON.stringify(parsed), schemaValid, elapsedMs: Date.now() - start };
      if (parsed.name && parsed.sum === 42) return { pass: true, score: "MODERATE", output: JSON.stringify(parsed), schemaValid: false, elapsedMs: Date.now() - start };
      return { pass: false, score: "WEAK", output: JSON.stringify(parsed), schemaValid: false, elapsedMs: Date.now() - start };
    } catch (e) {
      return { pass: false, score: "FAIL", output: e.message, schemaValid: false, elapsedMs: Date.now() - start };
    }
  }
  async function testToolUsageExtended(chatFn, model) {
    try {
      const result = await chatFn(model, [{ role: "system", content: "Use tools when needed." }, { role: "user", content: "What's weather in Tokyo and calculate 15*24?" }], { tools: [WEATHER_TOOL_DEFINITION, CALC_TOOL_DEFINITION] });
      const toolCalls = result.toolCalls || [];
      const hasWeather = toolCalls.some((t) => t.function?.name === "get_weather");
      const hasCalc = toolCalls.some((t) => t.function?.name === "calculate");
      let score = "FAIL";
      if (hasWeather && hasCalc && toolCalls.length >= 2) score = "STRONG";
      else if (hasWeather || hasCalc) score = "MODERATE";
      else if (toolCalls.length > 0) score = "WEAK";
      return { pass: toolCalls.length > 0, score, toolCalls: toolCalls.map((t) => t.function?.name || "?"), response: result.content, elapsedMs: result.elapsedMs };
    } catch (e) {
      return { pass: false, score: "ERROR", toolCalls: [], response: e.message, elapsedMs: 0 };
    }
  }
  async function getOllamaModels() {
    try {
      const res = await fetch(`${ollamaBase()}/api/tags`, { signal: AbortSignal.timeout(15e3) });
      if (!res.ok) return [];
      const data = await res.json();
      return (data.models || []).map((m) => m.name).filter(Boolean);
    } catch (err) {
      debugLog("model-test", "failed to list Ollama models", err);
      return [];
    }
  }
  function getCurrentModel(ctx) {
    return ctx.model?.id;
  }
  async function testModelExtended(model, ctx) {
    const lines = [];
    const totalStart = Date.now();
    const providerInfo = ctx ? detectProvider(ctx) : { kind: "ollama", name: "ollama" };
    lines.push(branding);
    lines.push(section(`MODEL: ${model}`));
    lines.push(info(`Provider: ${providerInfo.name} (${providerInfo.kind})`));
    const chatFn = makeChatFn(providerInfo);
    const toolChatFn = providerInfo.kind === "ollama" ? makeOllamaToolChatFn() : makeOpenAiChatFn(providerInfo.baseUrl || ollamaBase(), providerInfo.apiKey);
    const progress = (msg) => ctx?.ui?.notify?.(msg, "info");
    lines.push(section("REASONING TEST (EXTENDED)"));
    lines.push(info(`Testing ${REASONING_TESTS.length} reasoning puzzles...`));
    const reasoning = await testReasoningExtended(chatFn, model, progress);
    for (const r of reasoning.results) {
      const passMark = r.pass ? "\u2705" : "\u274C";
      const scoreLabel = r.score === "STRONG" ? ok : r.score === "MODERATE" ? warn : r.score === "WEAK" ? warn : fail;
      lines.push(scoreLabel(`${passMark} ${r.name} (${r.category}): ${r.score} - expected "${r.expectedAnswer}", got "${r.answer}"${r.details ? ` [${r.details}]` : ""}`));
    }
    lines.push(ok(`Average score: ${reasoning.score}`));
    progress("[2/3] Instruction following test...");
    lines.push(section("INSTRUCTION FOLLOWING TEST (EXTENDED)"));
    lines.push(info("Testing multi-step JSON schema compliance..."));
    await rateLimitDelay();
    const instructions = await testInstructionFollowingExtended(chatFn, model);
    lines.push(info(`Time: ${msHuman(instructions.elapsedMs)}`));
    reportInstructionScore(lines, instructions);
    lines.push(info(`Output: ${instructions.output}`));
    progress("[3/3] Tool usage test...");
    lines.push(section("TOOL USAGE TEST (EXTENDED)"));
    lines.push(info("Testing chained tool calls..."));
    await rateLimitDelay();
    const tools = await testToolUsageExtended(toolChatFn, model);
    lines.push(info(`Time: ${msHuman(tools.elapsedMs)}`));
    if (tools.score === "STRONG" || tools.score === "MODERATE") lines.push(ok(`Tool calls: ${tools.toolCalls.join(", ")} (${tools.score})`));
    else lines.push(fail(`Tool calls: ${tools.toolCalls.length > 0 ? tools.toolCalls.join(", ") : "none"} (${tools.score})`));
    lines.push(info(`Response: ${sanitizeForReport(tools.response)}`));
    const totalMs = Date.now() - totalStart;
    const reasoningPassed = reasoning.results.filter((r) => r.pass).length;
    const reasoningTotal = reasoning.results.length;
    const instructionPassed = instructions.pass ? 1 : 0;
    const toolPassed = tools.pass ? 1 : 0;
    const totalPassed = reasoningPassed + instructionPassed + toolPassed;
    const totalTests = reasoningTotal + 1 + 1;
    lines.push(...formatTestSummary([
      { name: "Reasoning", pass: reasoning.score === "STRONG" || reasoning.score === "MODERATE", score: reasoning.score },
      { name: "Instructions", pass: instructions.pass, score: instructions.score },
      { name: "Tool Usage", pass: tools.pass, score: tools.score }
    ], totalMs));
    lines.push("");
    lines.push(info(`Detailed: Reasoning ${reasoningPassed}/${reasoningTotal} tests passed, Instructions ${instructionPassed}/1, Tool Usage ${toolPassed}/1`));
    lines.push(...formatRecommendation(model, totalPassed, totalTests));
    return lines.join("\n");
  }
  async function testModel(model, ctx) {
    return testModelExtended(model, ctx);
  }
  pi.registerCommand("model-test", {
    description: "Test a model for reasoning ability, tool usage, and instruction following. Uses extended test flow with 20 reasoning puzzles.",
    detailedHelp: "\n\n\u{1F50D} Model Testing Extension\n\nThis extension tests AI models across multiple dimensions:\n\u2022 Reasoning: 20 diverse puzzles (logic, math, spatial, commonsense)\n\u2022 Tool Usage: Ability to use available tools effectively\n\u2022 Instruction Following: How well the model follows complex JSON instructions\n\n\u{1F4CB} Usage Examples:\n  /model-test                    # Test current model\n  /model-test gwen3:0.6b        # Test specific model\n  /model-test --all             # Test all Ollama models\n  /model-test --help            # Show this help\n  /model-test --clear-cache     # Clear tool support cache\n\n\u{1F527} Supported Providers:\n\u2022 Ollama (local/remote)\n\u2022 OpenRouter\n\u2022 Anthropic Claude\n\u2022 Google Gemini\n\u2022 OpenAI GPT\n\u2022 Groq\n\u2022 DeepSeek\n\u2022 Mistral\n\u2022 xAI\n\u2022 Together\n\u2022 Fireworks\n\u2022 Cohere\n\n\u{1F4A1} Tips:\n\u2022 Use --all to benchmark all your Ollama models\n\u2022 Clear cache if you encounter unexpected tool support issues\n\u2022 Results show detailed scoring and recommendations\n",
    getArgumentCompletions: async (prefix) => {
      try {
        const models = await getOllamaModels();
        return models.map((m) => ({ label: m, description: `Test ${m}` })).filter((m) => m.label.startsWith(prefix));
      } catch (err) {
        debugLog("model-test", "failed to get model completions", err);
        return [];
      }
    },
    handler: async (args, ctx) => {
      if (!ctx.hasUI) {
        ctx.ui.notify("model-test requires TUI mode", "error");
        return;
      }
      const arg = args.trim();
      if (arg === "--help") {
        ctx.ui.notify(
          "\u{1F50D} Model Testing Extension\n\n\u{1F4CB} Usage:\n  /model-test [model]     - Test current or specific model\n  /model-test --all        - Test all Ollama models\n  /model-test --clear-cache - Clear tool support cache\n\n\u{1F527} This extension runs the extended test flow by default,\ntesting 20 reasoning puzzles plus tool usage and instructions.\n\n\u{1F527} Examples:\n  /model-test              # Test current model\n  /model-test gpt-4        # Test specific model\n  /model-test --all        # Benchmark all Ollama models",
          "info"
        );
        return;
      }
      if (arg === "--clear-cache") {
        try {
          const fs3 = __require("node:fs");
          if (fs3.existsSync(TOOL_SUPPORT_CACHE_PATH)) {
            fs3.unlinkSync(TOOL_SUPPORT_CACHE_PATH);
            ctx.ui.notify("Tool support cache cleared successfully", "info");
          } else {
            ctx.ui.notify("No cache file found to clear", "info");
          }
        } catch (err) {
          ctx.ui.notify("Could not clear cache", "error");
        }
        return;
      }
      if (arg === "--all") {
        const providerInfo = detectProvider(ctx);
        if (providerInfo.kind !== "ollama") {
          ctx.ui.notify(`--all is only supported for Ollama models. Current provider: ${providerInfo.name} (${providerInfo.kind})`, "error");
          return;
        }
        ctx.ui.notify("Testing all models \u2014 this will take a while...", "info");
        let models;
        try {
          models = await getOllamaModels();
        } catch (err) {
          debugLog("model-test", "failed to list Ollama models for --all", err);
          ctx.ui.notify("Could not list Ollama models", "error");
          return;
        }
        if (models.length === 0) {
          ctx.ui.notify("No models found in Ollama", "error");
          return;
        }
        for (const model2 of models) {
          ctx.ui.notify(`Testing ${model2}...`, "info");
          try {
            const report = await testModelExtended(model2, ctx);
            pi.sendMessage({
              customType: "model-test-report",
              content: report,
              display: { type: "content", content: report },
              details: { model: model2, timestamp: (/* @__PURE__ */ new Date()).toISOString() }
            });
          } catch (e) {
            ctx.ui.notify(`Failed to test ${model2}: ${e.message}`, "error");
          }
        }
        ctx.ui.notify(`Done testing ${models.length} models`, "info");
        return;
      }
      const model = arg || getCurrentModel(ctx);
      if (!model) {
        ctx.ui.notify("No model specified and no model currently selected", "error");
        return;
      }
      ctx.ui.notify(`Testing ${model}...`, "info");
      try {
        const report = await testModel(model, ctx);
        pi.sendMessage({
          customType: "model-test-report",
          content: report,
          display: { type: "content", content: report },
          details: { model, timestamp: (/* @__PURE__ */ new Date()).toISOString() }
        });
      } catch (e) {
        let errorMessage = "Model test failed";
        if (e.message) {
          errorMessage += `: ${e.message}`;
        }
        ctx.ui.notify(errorMessage, "error");
      }
    }
  });
  pi.registerTool({
    name: "model_test",
    label: "Model Test",
    description: "Test a model for reasoning ability, tool usage capability, and instruction following. Uses extended test flow with 20 reasoning puzzles. Supports both Ollama and built-in cloud providers.",
    promptSnippet: "model_test - test a model's capabilities",
    promptGuidelines: [
      "When the user asks to test or evaluate a model, call model_test with the model name."
    ],
    parameters: {
      type: "object",
      properties: {
        model: { type: "string", description: "Model name to test (e.g. qwen3:0.6b, anthropic/claude-3.5-sonnet). If omitted, tests the current model." }
      }
    },
    execute: async (_toolCallId, _params, _signal, _onUpdate, ctx) => {
      const params = _params;
      const model = params?.model || getCurrentModel(ctx);
      if (!model) {
        return {
          content: [{ type: "text", text: "No model currently selected to test." }],
          isError: true
        };
      }
      try {
        const report = await testModel(model, ctx);
        return {
          content: [{ type: "text", text: report }],
          isError: false
        };
      } catch (e) {
        let errorMessage = "Model test failed";
        if (e.message) {
          errorMessage += `: ${e.message}`;
        }
        return {
          content: [{ type: "text", text: errorMessage }],
          isError: true
        };
      }
    }
  });
}
export {
  model_test_default as default
};
