var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class ExtensionError extends Error {
  constructor(message, code) {
    super(message);
    __publicField(this, "code", code);
    this.name = "ExtensionError";
  }
}
class ConfigError extends ExtensionError {
  constructor(message, configPath, suggestion) {
    super(message, "CONFIG_ERROR");
    __publicField(this, "configPath", configPath);
    __publicField(this, "suggestion", suggestion);
    this.name = "ConfigError";
  }
  /**
   * Create a user-friendly error message with suggestions.
   */
  toUserMessage() {
    let msg = this.message;
    if (this.configPath) {
      msg += ` (Config: ${this.configPath})`;
    }
    if (this.suggestion) {
      msg += `
\u{1F4A1} Suggestion: ${this.suggestion}`;
    }
    return msg;
  }
}
class ApiError extends ExtensionError {
  constructor(message, statusCode, url) {
    super(message, "API_ERROR");
    __publicField(this, "statusCode", statusCode);
    __publicField(this, "url", url);
    this.name = "ApiError";
  }
}
class ExtensionTimeoutError extends ExtensionError {
  constructor(message, timeoutMs) {
    super(message, "TIMEOUT");
    __publicField(this, "timeoutMs", timeoutMs);
    this.name = "ExtensionTimeoutError";
  }
}
class SecurityError extends ExtensionError {
  constructor(message, rule, detail) {
    super(message, "SECURITY_VIOLATION");
    __publicField(this, "rule", rule);
    __publicField(this, "detail", detail);
    this.name = "SecurityError";
  }
}
class ToolError extends ExtensionError {
  constructor(message, toolName) {
    super(message, "TOOL_ERROR");
    __publicField(this, "toolName", toolName);
    this.name = "ToolError";
  }
}
export {
  ApiError,
  ConfigError,
  ExtensionError,
  ExtensionTimeoutError,
  SecurityError,
  ToolError
};
